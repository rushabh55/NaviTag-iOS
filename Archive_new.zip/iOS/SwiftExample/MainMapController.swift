//
//  MainMap.swift
//  SwiftExample
//
//  Created by Shashank Katkar on 2/8/15.
//  Copyright (c) 2015 Sachin Kesiraju. All rights reserved.
//

import Foundation

class MainMapController
{
    
}